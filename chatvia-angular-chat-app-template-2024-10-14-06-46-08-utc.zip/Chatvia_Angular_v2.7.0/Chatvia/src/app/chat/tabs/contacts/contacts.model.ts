export interface Contacts {
    id: number;
    name: string;
}
